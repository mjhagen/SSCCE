INSERT INTO foo ( id, name ) VALUES ( 1, 'myFirstFoo' );
INSERT INTO bar ( id, name, fooid ) VALUES ( 2, 'myFirstBar', 1 );

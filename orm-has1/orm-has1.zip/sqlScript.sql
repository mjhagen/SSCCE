INSERT INTO foo ( id, name ) VALUES ( 1, 'myFirstFoo' );
INSERT INTO bar ( id, name, fooid, deleted ) VALUES ( 2, 'myFirstBar', 1, 't' );
INSERT INTO baz ( id, name, fooid, deleted ) VALUES ( 2, 'myFirstBaz', 1, 't' );
